# asilum-brain
ASiLUM — fashion recommendation brain: 5-bridge peronalization engine, knowledge base, and permitted-sorce listing ingestion (Next.js).
