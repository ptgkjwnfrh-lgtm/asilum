# asilum-brain — staged upgrade (ready to commit)

Five files, tested against the real repo (cloned `main`) and the real 1,000-item
catalog — **21/21 integration checks pass** (`integration.test.mjs` included).

## Files → repo paths

| Staged file | Repo path | What it is |
|---|---|---|
| `lib/brain/stylist.js` | `lib/brain/stylist.js` | **NEW** — outfit engine on your tag vectors + TAG_AFFINITY + era/price coherence, **fit-gated through sizing.js** (never proposes a confidently-bad fit; emits fitPhrase notes per piece). `buildSlate(pool, profile, 3, {fitProfile, events})` → 3 diverse outfits with conf 58–99. |
| `lib/brain/memory.js` | `lib/brain/memory.js` | **NEW** — clock-based forgetting. `applyTimeDecay(profile)` (6-day idle half-life, forget events logged to `_meta.forgotten`), `noteActivity()` ring buffer, `vizState()` for the viz. All state rides in `_meta`, so it persists with the profile and never touches bridge math. |
| `lib/brain/lexicon.js` | `lib/brain/lexicon.js` | **REPLACE — fixes a live bug.** `index.js#resolveToken` calls `foldToken(token)→string` and `lexiconVector(token)→vec|null`, but the current lexicon exports `foldToken(acc,token)` and `lexiconVector(tokens[])→{vec,hits}`. Result today: the lexicon path silently returns zeros and cold-start only works via the designer KB. This version matches the orchestrator contract, keeps `lexiconVectorAll()` for aggregate callers, and adds ~25 garment/gear tokens (goretex, cargo, selvedge, archive, corset…) so ingested eBay titles tag meaningfully. |
| `lib/ingest/ebay.js` | `lib/ingest/ebay.js` | **NEW** — official Browse API adapter: client-credentials OAuth (env keys), token cache, `searchEbay(q)` → items normalized to the catalog schema and run through `inferTags` + `sizeRecord` + era/category guessing, deduped by id. Your exact ingestion plan, steps 1–5. |
| `app/api/ebay/route.js` | `app/api/ebay/route.js` | **NEW** — `GET /api/ebay?q=…` server route. No proxy needed; set `EBAY_CLIENT_ID`, `EBAY_CLIENT_SECRET`, `EBAY_ENV` in Vercel → live listings, brain-tagged, size-recorded. |
| `app/components/BrainViz.jsx` | `app/components/BrainViz.jsx` | **NEW** — the brain's face: rotating word-sphere of the 10 tags, edges = TAG_AFFINITY. White pulses + lit edges when learning; red flares + snapping/falling edges on forget events. Drag to rotate. `<BrainViz {...vizState(profile)} />`. |

## Two-line wiring (the only edits to existing files)

**`app/api/interaction/route.js`** — after the existing `learn(...)` call:
```js
import { noteActivity } from "../../../lib/brain/memory.js";
profile = noteActivity(profile, item, action);   // before saveProfile
```

**`app/api/feed/route.js`** — after loading the profile:
```js
import { applyTimeDecay } from "../../../lib/brain/memory.js";
({ profile } = applyTimeDecay(profile));          // idle forgetting on read
```

**`app/page.js`** — render the sphere (e.g. behind a "brain" toggle):
```jsx
import BrainViz from "./components/BrainViz.jsx";
import { vizState } from "../lib/brain/memory.js";
// profile comes back from /api/feed or /api/train responses if you return it;
// simplest: add `profile` to the feed route's JSON and keep it in state.
{showBrain && <BrainViz {...vizState(profile)} />}
```

## Commit order (each is safe/independent; main auto-deploys on Vercel)
1. `lib/brain/lexicon.js` — bug fix, improves cold-start immediately.
2. `lib/brain/memory.js` + the two wiring lines — forgetting goes live.
3. `lib/brain/stylist.js` — engine only; UI can come later.
4. `lib/ingest/ebay.js` + `app/api/ebay/route.js` — inert until env keys are set
   in Vercel (Settings → Environment Variables). Keys go in yourself, never in chat.
5. `app/components/BrainViz.jsx` + page.js wiring.

## Also in this folder (standalone prototype)
`../index.html` is the full standalone build (feed, social, editorial, bag,
vault, brain viz) — useful as the design/UX reference for bringing those
surfaces into the Next app; its `README.md` documents each system.
