"use client";

// app/page.js
// Asilum moodboard UI. Train the brain from a text prompt, fetch a ranked
// feed of real listings (with matched free imagery), and feed every
// favorite/skip back into the learning loop. Each card also explains WHY it
// surfaced (which bridge won) and lets you mute a specific tag.

import { useEffect, useState, useCallback } from "react";
import { fitPhrase, fitScore } from "../lib/brain/sizing.js";

const USER = "demo-user";

// Turn the winning bridge into a short, human phrase (explainability).
const BRIDGE_REASON = {
  alpha: "matches your taste",
  beta: "leans into a trait you love",
  delta: "a bit of variety",
  epsilon: "a wildcard for you",
  ad: "sponsored",
};

function reasonFor(item) {
  const parts = item && item._parts ? item._parts : null;
  if (!parts) return null;
  let bestK = null, bestV = -Infinity;
  for (const k in parts) {
    if (parts[k] > bestV) { bestV = parts[k]; bestK = k; }
  }
  return bestK ? BRIDGE_REASON[bestK] || null : null;
}

// Format the era object into a compact human label (season year, or decade).
function eraLabel(era) {
  if (!era) return null;
  if (era.season && era.year) return era.season + " " + era.year;
  if (era.year) return String(era.year);
  if (era.decade) return era.decade;
  return null;
}

// ---- Fit profile (client-only; measurements never leave the browser) ----
const FIT_KEY = "asilum-fit-profile";
const EMPTY_FIT = { usualSize: "", chest: "", waist: "" };
function loadFitProfile() {
  if (typeof window === "undefined") return EMPTY_FIT;
  try {
    const raw = window.localStorage.getItem(FIT_KEY);
    return raw ? { ...EMPTY_FIT, ...JSON.parse(raw) } : EMPTY_FIT;
  } catch { return EMPTY_FIT; }
}
function saveFitProfile(p) {
  try { window.localStorage.setItem(FIT_KEY, JSON.stringify(p)); } catch {}
}
function fitProfileForBrain(f) {
  const m = {};
  if (f.chest) m.chest = parseFloat(f.chest);
  if (f.waist) m.waist = parseFloat(f.waist);
  return { usualSize: (f.usualSize || "").toUpperCase(), measurements: m };
}

export default function Home() {
  const [prompt, setPrompt] = useState("");
  const [epsilon, setEpsilon] = useState(false);
  const [epsilonAuto, setEpsilonAuto] = useState(false);
  const [split, setSplit] = useState(null);
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(false);
  const [fit, setFit] = useState(EMPTY_FIT);
  const [showFit, setShowFit] = useState(false);
  useEffect(() => { setFit(loadFitProfile()); }, []);
  const fitBrain = fitProfileForBrain(fit);
  function updateFit(k, v) {
    setFit((prev) => { const n = { ...prev, [k]: v }; saveFitProfile(n); return n; });
  }

  const loadFeed = useCallback(async () => {
    setLoading(true);
    try {
      const qs = new URLSearchParams({
        user: USER,
        epsilon: epsilon ? "1" : "0",
        q: prompt,
      });
      const res = await fetch("/api/feed?" + qs.toString());
      const data = await res.json();
      setSplit(data.split || null);
      setItems(data.items || []);
      setEpsilonAuto(!!data.epsilonAuto);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  }, [epsilon, prompt]);

  useEffect(() => { loadFeed(); }, []); // initial cold feed

  async function train() {
    if (!prompt.trim()) { loadFeed(); return; }
    setLoading(true);
    try {
      await fetch("/api/train", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ user: USER, prompt }),
      });
      await loadFeed();
    } finally {
      setLoading(false);
    }
  }

  async function react(item, action) {
    // optimistic: remove skipped items right away
    if (action === "hide" || action === "skip") {
      setItems((prev) => prev.filter((x) => x.id !== item.id));
    }
    try {
      await fetch("/api/interaction", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ user: USER, item, action }),
      });
      // A favorite can shift momentum/exploration; refresh to reflect it.
      if (action === "favorite") loadFeed();
    } catch (e) { console.error(e); }
  }

  // Per-tag mute: send a synthetic single-tag item as a skip so the brain
  // deducts from exactly that tag (reuses the existing beta pushback), then
  // refresh the feed. Lets you prune a runaway dimension without a reset.
  async function muteTag(tag) {
    const synthetic = { id: "mute:" + tag + ":" + Date.now(), tags: { [tag]: 1 } };
    try {
      await fetch("/api/interaction", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ user: USER, item: synthetic, action: "skip" }),
      });
      loadFeed();
    } catch (e) { console.error(e); }
  }

  const splitLabels = split
    ? Object.entries(split).map(([k, v]) => (
        <span className="chip" key={k}>
          {k} <b>{Math.round(v)}%</b>
        </span>
      ))
    : null;

  return (
    <div className="wrap">
      <div className="top">
        <div className="brand">asilum<span>.</span></div>
        <div className="tag">a fashion brain that learns your taste across five bridges</div>
      </div>

      <div className="controls">
        <input
          type="text"
          placeholder="describe a mood, era, designer, film, feeling…"
          value={prompt}
          onChange={(e) => setPrompt(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && train()}
        />
        <button className="btn" onClick={train}>Train feed</button>
        <label className="toggle">
          <input
            type="checkbox"
            checked={epsilon}
            onChange={(e) => setEpsilon(e.target.checked)}
          />
          EPSILON on
        </label>
      </div>

      <div className="fitrow">
        <button className="fitbtn" onClick={() => setShowFit((s) => !s)}>
          {showFit ? "hide sizing" : "my sizing"}
        </button>
        {fit.usualSize ? (
          <span className="fitnote">usually {fit.usualSize.toUpperCase()}</span>
        ) : (
          <span className="fitnote dim">add your size for fit hints</span>
        )}
      </div>
      {showFit ? (
        <div className="fitform">
          <label>
            usual size
            <select value={fit.usualSize} onChange={(e) => updateFit("usualSize", e.target.value)}>
              <option value="">—</option>
              {["XXS","XS","S","M","L","XL","XXL","XXXL"].map((s) => (
                <option key={s} value={s}>{s}</option>
              ))}
            </select>
          </label>
          <label>
            chest (in)
            <input type="number" inputMode="decimal" value={fit.chest}
              onChange={(e) => updateFit("chest", e.target.value)} placeholder="40" />
          </label>
          <label>
            waist (in)
            <input type="number" inputMode="decimal" value={fit.waist}
              onChange={(e) => updateFit("waist", e.target.value)} placeholder="32" />
          </label>
          <span className="fithint">stored only on this device</span>
        </div>
      ) : null}
      <div className="splitbar">{splitLabels}</div>

      {epsilonAuto && (
        <div className="autonote">trying something different — you seemed in a rut</div>
      )}

      {loading && <div className="empty">thinking…</div>}
      {!loading && items.length === 0 && (
        <div className="empty">No items yet — train the feed with a prompt.</div>
      )}

      <div className="grid">
        {items.map((it) => {
          const reason = reasonFor(it);
          return (
            <div className="card" key={it.id}>
              <div className="imgwrap">
                {it.img ? (
                  <img src={it.img} alt={it.alt || it.title} loading="lazy" />
                ) : null}
              </div>
              <div className="body">
                <div className="ttl">{it.title}</div>
                <div className="brand2">{it.brand}</div>
                <div className="meta">
                  {it.category ? <span className="cat">{it.category}</span> : null}
                  {eraLabel(it.era) ? <span className="era">{eraLabel(it.era)}</span> : null}
                </div>
                {it.size ? (
                  <div className="size">
                    {it.size.label ? <span className="szlabel">{it.size.label}</span> : null}
                    {fitPhrase(it.size, fitBrain) ? (
                      <span className="szfit">{fitPhrase(it.size, fitBrain)}</span>
                    ) : null}
                  </div>
                ) : null}
                {it.designers && it.designers.length ? (
                  <div className="designers">
                    {it.designers.map((d) => (
                      <span className="dz" key={d}>{d}</span>
                    ))}
                  </div>
                ) : null}
                {it.price ? (
                  <div className="price">{it.currency || "USD"} {it.price}</div>
                ) : null}
                {reason ? <div className="why">{reason}</div> : null}
                <div className="tags">
                  {Object.keys(it.tags || {})
                    .slice(0, 3)
                    .map((t) => (
                      <span className="t" key={t}>
                        {t}
                        <button
                          className="mute"
                          title={"less " + t}
                          onClick={() => muteTag(t)}
                        >
                          ×
                        </button>
                      </span>
                    ))}
                </div>
                <div className="actions">
                  <button onClick={() => react(it, "favorite")}>Favorite</button>
                  <button onClick={() => react(it, "skip")}>Skip</button>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
