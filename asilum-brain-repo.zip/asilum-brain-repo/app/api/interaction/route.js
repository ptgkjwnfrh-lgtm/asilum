// app/api/interaction/route.js
// POST /api/interaction
// Body: { user, item: {id, tags}, action }  action in favorite|dwell|skip|hide
// Records the interaction and updates + persists the user's learned profile.

import { NextResponse } from "next/server";
import { Brain } from "../../../lib/brain/index.js";
import { getProfile, saveProfile, recordInteraction } from "../../../lib/db/index.js";

export const dynamic = "force-dynamic";

const VALID = new Set(["favorite", "dwell", "skip", "hide"]);

export async function POST(req) {
  let body = {};
  try { body = await req.json(); } catch { body = {}; }
  const userId = body.user || "guest";
  const item = body.item || null;
  const action = body.action || "";

  if (!item || !item.id || !VALID.has(action)) {
    return NextResponse.json(
      { error: "item{id,tags} and valid action required" },
      { status: 400 }
    );
  }

  const prior = (await getProfile(userId)) || {};
  const updated = Brain.learn(prior, item, action);

  await saveProfile(userId, updated);
  await recordInteraction(userId, item.id, action);

  return NextResponse.json({ userId, action, profile: updated });
}
