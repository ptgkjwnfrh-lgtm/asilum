// app/api/train/route.js
// POST /api/train
// Body: { user, prompt }
// Cold-starts or reshapes a user's profile from a free-text prompt / moodboard
// caption, persists it, and returns the resulting tag vector.

import { NextResponse } from "next/server";
import { Brain } from "../../../lib/brain/index.js";
import { getProfile, saveProfile } from "../../../lib/db/index.js";

export const dynamic = "force-dynamic";

export async function POST(req) {
  let body = {};
  try { body = await req.json(); } catch { body = {}; }
  const userId = body.user || "guest";
  const prompt = body.prompt || "";

  if (!prompt) {
    return NextResponse.json({ error: "prompt required" }, { status: 400 });
  }

  // Blend the prompt-derived vector into any existing profile.
  const prior = (await getProfile(userId)) || {};
  const fresh = Brain.coldStart(prompt).profile;
  const blended = { ...prior };
  for (const k in fresh) {
    blended[k] = ((blended[k] || 0) + fresh[k]) / (blended[k] ? 2 : 1);
  }

  await saveProfile(userId, blended);
  return NextResponse.json({ userId, profile: blended });
}
