// app/api/feed/route.js
// GET /api/feed?user=<id>&epsilon=<0|1>&q=<prompt>
// Returns a ranked, personalized feed. Uses the persisted profile if present,
// otherwise cold-starts from the optional text prompt. Epsilon (exploration)
// can be forced via the query param OR auto-fired by the brain when it detects
// the user is bored (a run of skips) -- see buildFeed's fatigue logic.

import { NextResponse } from "next/server";
import { Brain } from "../../../lib/brain/index.js";
import { CATALOG } from "../../../lib/ingest/catalog.js";
import { listItems, getProfile } from "../../../lib/db/index.js";

export const dynamic = "force-dynamic";

export async function GET(req) {
  const { searchParams } = new URL(req.url);
  const userId = searchParams.get("user") || "guest";
  const epsilonParam = searchParams.get("epsilon") === "1";
  const q = searchParams.get("q") || "";

  // Item pool: DB items if available, else the seed catalog.
  let pool = [];
  try { pool = await listItems(200); } catch { pool = []; }
  if (!pool || pool.length === 0) pool = CATALOG;

  // Profile: persisted, else cold-start from prompt.
  let profile = {};
  try { profile = await getProfile(userId); } catch { profile = {}; }
  if ((!profile || Object.keys(profile).length === 0) && q) {
    profile = Brain.coldStart(q).profile;
  }

  const { split, items, epsilonActive, epsilonAuto } = Brain.buildFeed(
    { profile, epsilonActive: epsilonParam, seenIds: new Set() },
    pool
  );

  return NextResponse.json({
    userId,
    epsilonActive,
    epsilonAuto,
    split,
    count: items.length,
    items,
  });
}
