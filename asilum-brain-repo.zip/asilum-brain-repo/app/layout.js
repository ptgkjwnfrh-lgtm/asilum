// app/layout.js
// Root layout for the Asilum moodboard app.

import "./globals.css";

export const metadata = {
  title: "Asilum — the fashion brain",
  description:
    "A learning moodboard engine that reads your taste across five bridges and builds a personal feed of real listings.",
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
